def joke():
    return (u'works')